import java.util.*;

public class RealEstate {
    public static User[] usersList = new User[0];
    public static Property[] propertyList = new Property[0];
    public City[] cities;
    private boolean isBroker;

    public RealEstate() {
        cities = new City[]{
                new City("Ashdod", "Darom", new String[]{"Eli cohen", "Yona", "Yarkon"}),
                new City("Netanya", "Sharon", new String[]{"Florentin", "David"}),
                new City("Raanana", "Sharon", new String[]{"Narkis", "Nordeu"}),
                new City("Haifa", "North", new String[]{"Sokolov", "Rimon"}),
                new City("Tveria", "North", new String[]{"Kaplan", "Tamar"}),
                new City("Eilat", "Darom", new String[]{"Remez", "Macabim"}),
                new City("Ashkelon", "Darom", new String[]{"Shapira", "Milrod"}),
                new City("Holon", "Center", new String[]{"Zait", "HaDekel"}),
                new City("Yafo", "Center", new String[]{"Almog", "Macabim"}),
                new City("Jerusalem", "East", new String[]{"Sapir", "Agor"}),
        };
    }

    public void createUser() {
        User newUser = new User();
        System.out.print("Enter your username: ");
        Scanner scanner = new Scanner(System.in);
        String userName = scanner.nextLine();
        newUser.isValidUserName(userName);
        if (!newUser.isValidUserName(userName)) {
            do {
                System.out.println("Your username already exists. try again");
                userName = scanner.next();
                newUser.isValidUserName(userName);
            } while (!newUser.isValidUserName(userName));
        } else {
            newUser.setUserName(userName);
        }
        System.out.println("Enter a password: ");
        System.out.println("[Password must contain: % / $ / _ characters ,And minimum of 5 characters.]");
        String userPassword = scanner.nextLine();
        if (!newUser.isPasswordValid(userPassword)) {
            do {
                System.out.println("Your password do not meet the requirements, try again!");
                userPassword = scanner.nextLine();
                newUser.isPasswordValid(userPassword);
            } while (!newUser.isPasswordValid(userPassword));
        } else {
            newUser.setUserPassword(userPassword);
        }
        System.out.print("Enter your phone number: ");
        String userPhoneNumber = scanner.nextLine();
        if (!newUser.isPhoneNumberValid(userPhoneNumber)) {
            do {
                System.out.println("Your phone number is invalid, try again!");
                userPhoneNumber = scanner.nextLine();
                newUser.isPhoneNumberValid(userPhoneNumber);
            } while (!newUser.isPhoneNumberValid(userPhoneNumber));
        }
        newUser.setUserPhoneNumber(userPhoneNumber);
        System.out.println("Are you a broker?");
        System.out.println("[1] - Yes.");
        System.out.println("[2] - No.");
        int userIsBroker;
        userIsBroker = scanner.nextInt();
        switch (userIsBroker) {
            case Def.YES:
                isBroker = true;
                break;
            case Def.NO:
                isBroker = false;
                break;
            default:
                break;
        }
        newUser.setBroker(isBroker);
        addUser(usersList, newUser);
    }

    public User userLogin() {
        System.out.println("Enter your sign-in username:");
        Scanner scanner = new Scanner(System.in);
        String loginUserName = scanner.nextLine();
        System.out.println("Enter your sign-in password:");
        String loginUserPassword = scanner.nextLine();
        for (int i = 0; i < usersList.length; i++) {
            if (usersList[i].equals(loginUserName, loginUserPassword)) {
                System.out.println("Login success! What you like to do?");
                return usersList[i];
            }
        }
        return null;
    }

    public void menuPrint() {
        System.out.println("[1] - Post a new property");
        System.out.println("[2] - Remove a post of property");
        System.out.println("[3] - Show all property's");
        System.out.println("[4] - Show all property's posted by you");
        System.out.println("[5] - Search for a property");
        System.out.println("[6] - Logout and return to main menu");
    }

    public void actionByUserChoose(int userSelection, User user)  {
        switch (userSelection) {
            case Def.POST_PROPERTY:
                postNewProperty(user);
                break;
            case Def.REMOVE_PROPERTY:
                removeProperty(user);
                userMainMenu(user);
                break;
            case Def.PRINT_ALL_PROPERTYS:
                printAllPropertys();
                userMainMenu(user);
                break;
            case Def.PRINT_ALL_USER_PROPERTYS:
                printProperties(user);
                userMainMenu(user);
                break;
            case Def.PROPERTY_SEARCH:
                search();
                userMainMenu(user);
                break;
            case Def.EXIT:
                System.out.println("Disconnected.");
                user = null;
                Main.realEstateAction();
                return;
            default:
                System.out.println("Invalid selection, try again.");
                userMainMenu(user);
        }
    }

    private Property[] search() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("REMINDER: You can type [-999] to filter a value ");
        System.out.print("[1] - For sale || [2] - For sale");
        int rentOrSale = scanner.nextInt();
        String propertyCategory = "";
        if (rentOrSale == Def.FOR_SALE) {
            propertyCategory = "For sale";
        } else if (rentOrSale == Def.FOR_RENT) {
            propertyCategory = "For rent";
        }
        System.out.println("What is the type of the property? ");
        System.out.print("[1] - Apartment || [2] - Penthouse apartment || [3] - Private house");
        int propertyTypeInput = scanner.nextInt();
        System.out.print("How many rooms?");
        int propertyRoomsInput = scanner.nextInt();
        Scanner price = new Scanner(System.in);
        System.out.print("What is the minimum price range?");
        int minimum = price.nextInt();
        System.out.print("What is the maximum price range?");
        int maximum = price.nextInt();
        Property[] filteredList;
        filteredList = searchByFilter(propertyList, rentOrSale, minimum, maximum, propertyCategory, propertyTypeInput, propertyRoomsInput);
        return filteredList;
    }

    private Property[] searchByFilter(Property[] propertyList, int rentOrSale, int min, int max, String propertyCategory, int propertyTypeInput, int propertyRoomsInput) {
        Property[] filteredList = null;
        for (int i = 0; i < propertyList.length; i++) {
            if (rentOrSale != Def.FILTERING_PARAMETER || propertyList[i].getPropertyCategory().equals(propertyCategory)) {
                if (rentOrSale != Def.FILTERING_PARAMETER || propertyList[i].getPropertyType() == propertyTypeInput) {
                    if (rentOrSale != Def.FILTERING_PARAMETER || propertyList[i].getPropertyRooms() == propertyRoomsInput) {
                        if (min != Def.FILTERING_PARAMETER || max != Def.FILTERING_PARAMETER || propertyList[i].getPropertyPrice() <= max && propertyList[i].getPropertyPrice() >= min) {
                            System.out.println(propertyList[i].toString());
                            addProperty(filteredList, propertyList[i]);
                        }
                    }
                }
            }
        }
        return propertyList;
    }

    private void printProperties(User user) {
        if (propertyList.length > Def.NULL) {
            for (int i = 0; i < propertyList.length; i++) {
                if (propertyList[i].getUser() == user) {
                    System.out.println(propertyList[i].toString());
                }
            }
        }
    }

    private User removeProperty(User user) {
        if (propertyList.length > Def.NULL) {
            boolean isListedPropertys = false;
            int index = 0;
            int counter = 0;
            Property[] updatedPropertyList = new Property[propertyList.length - 1];
            for (int i = 0; i < propertyList.length; i++) {
                if (propertyList[i].getUser() == user) {
                    index = i;
                    counter++;
                    System.out.println("[" + counter + "]" + propertyList[index]);
                    isListedPropertys = true;
                } else {
                    System.out.println("You dont have any listed property.");
                    return user;
                }
            }
            if (isListedPropertys) {
                System.out.println("Choose the number of the property you want to remove");
                Scanner scanner = new Scanner(System.in);
                int userInput = scanner.nextInt();
                if (userInput == index + Def.ONE) {
                    for (int i = 0; i < updatedPropertyList.length; i++) {
                        if (propertyList[i] != propertyList[userInput]) {
                            propertyList[i] = updatedPropertyList[i];
                        }
                    }
                    propertyList = updatedPropertyList;
                    return user;
                }
            }
        } else {
            System.out.println("There is no propertys listed.");
            return user;
        }
        return user;
    }

    private void printAllPropertys() {
        if (propertyList.length > Def.NULL) {
            for (int i = 0; i < propertyList.length; i++) {
                System.out.println(propertyList[i].toString());
            }
        } else {
            System.out.println("No propertys yet listed");
        }
    }

    public void userMainMenu(User user) {
        menuPrint();
        int userSelection;
        Scanner selectionScanner = new Scanner(System.in);
        userSelection = selectionScanner.nextInt();
        actionByUserChoose(userSelection, user);
    }

    private static User[] addUser(User[] originalUsersList, User user) {
        User[] newUsersList = new User[originalUsersList.length + Def.ONE];
        for (int i = 0; i < originalUsersList.length; i++) {
            newUsersList[i] = originalUsersList[i];
        }
        newUsersList[newUsersList.length - Def.ONE] = user;
        usersList = newUsersList;
        return usersList;
    }

    private static Property[] addProperty(Property[] properties, Property property) {
        Property[] newPropertyList = new Property[properties.length + Def.ONE];
        for (int i = 0; i < properties.length; i++) {
            newPropertyList[i] = properties[i];
        }
        newPropertyList[newPropertyList.length - Def.ONE] = property;
        propertyList = newPropertyList;
        return propertyList;
    }

    private int countUserPosts(User user) {
        int counter = 0;
        if (propertyList.length > Def.NULL) {
            for (int i = 0; i < propertyList.length; i++) {
                if (propertyList[i].getUser().equals(user)) {
                    counter++;
                }
            }
        }
        return counter;
    }

//    public City getUserCity(User user){
//        System.out.println(" ");
//        System.out.println("Enter the city you want to post property from the list");
//        boolean findCity = false;
//        int index = -1;
//        Scanner scanner = new Scanner(System.in);
//        String userCityInput = scanner.nextLine().toLowerCase();
//        for (int k = 0; k < cities.length && !findCity; k++) {
//            if (userCityInput.equals(cities[k].getCity().toLowerCase())) {
//                findCity = true;
//                index = k;
//            }
//        }
//        return cities[index];
//    }
    private boolean postNewProperty(User user) {
        boolean isUserCanPostProperty = false;
        int counter = countUserPosts(user);
        if (user.isBroker()) {
            if (counter < Def.BROKER_PROPERTY_LIMIT) {
                isUserCanPostProperty = true;
            }
        } else {
            if (counter < Def.USER_PROPERTY_LIMIT) {
                isUserCanPostProperty = true;
            }
        }
        if (isUserCanPostProperty) {
            Property property = new Property();
            property.setUser(user);
            for (int k = 0; k < cities.length; k++) {
                System.out.println(cities[k].getCity() + "," + " " + cities[k].getDistrict() + "," + " " + Arrays.toString(cities[k].getStreets()));
            }
            System.out.println(" ");
            System.out.println("Enter the city you want to post property from the list");
            boolean findCity = false;
            int index = -1;
            Scanner scanner = new Scanner(System.in);
            String userCityInput = scanner.nextLine().toLowerCase();
            for (int k = 0; k < cities.length && !findCity; k++) {
                if (userCityInput.equals(cities[k].getCity().toLowerCase())) {
                    findCity = true;
                    index = k;
                }
            }
            if (findCity) {
                boolean propertyPostSuccess = false;
                City userCity = cities[index];
                property.setCity(userCity);
                String[] cityStreets = cities[index].getStreets();
                System.out.println(cities[index].toStringStreets());
                System.out.println("Which street you want to post property from the list?");
                String userStreetInput = scanner.nextLine().toLowerCase();
                for (int k = 0; k < cityStreets.length; k++) {
                    if (userStreetInput.equals(cityStreets[k].toLowerCase())) {
                        String address = cityStreets[k];
                        property.setAddress(address);
                    }
                }
                    System.out.println("What is the type of the property?");
                    System.out.println("[1] - Apartment");
                    System.out.println("[2] - Penthouse apartment");
                    System.out.println("[3] - Private house");
                    int userPropertyTypeInput;
                    int propertyFloor;
                    userPropertyTypeInput = scanner.nextInt();
                    if (userPropertyTypeInput == Def.APARTMENT) {
                        System.out.println("What floor is the apartment?");
                        propertyFloor = scanner.nextInt();
                        property.setPropertyFloor(propertyFloor);
                        property.setPropertyType(userPropertyTypeInput);
                    }
                    else if(userPropertyTypeInput == Def.PENTHOUSE || userPropertyTypeInput == Def.PRIVATE_HOUSE){
                        property.setPropertyType(userPropertyTypeInput);
                    }
                    System.out.println("How many rooms in the property?");
                    int propertyRooms = scanner.nextInt();
                    property.setPropertyRooms(propertyRooms);
                    System.out.println("What is the number of the property?");
                    int propertyNumber = scanner.nextInt();
                    property.setPropertyNumber(propertyNumber);
                    System.out.println("Is the property for sale or for rent?");
                    System.out.println("[1] - For sale");
                    System.out.println("[2] - For rent");
                    int propertyCategoryInput = scanner.nextInt();
                    String propertyCategory;
                    if (propertyCategoryInput == Def.FOR_SALE) {
                        propertyCategory = "For sale";
                        property.setPropertyCategory(propertyCategory);
                    } else if (propertyCategoryInput == Def.FOR_RENT) {
                        propertyCategory = "For rent";
                        property.setPropertyCategory(propertyCategory);
                    }
                    System.out.println("What is the price for the property?");
                    int propertyPrice;
                    scanner.nextLine();
                    propertyPrice = scanner.nextInt();
                    property.setPropertyPrice(propertyPrice);
                    addProperty(propertyList, property);
                    propertyPostSuccess = true;
                    if (propertyPostSuccess) {
                        System.out.println("Property posted!");
                        userMainMenu(user);
                    } else {
                        System.out.println("Property didn't posted.");
                    }
                }
            }
        return isUserCanPostProperty;
    }
}