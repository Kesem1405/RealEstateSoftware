import java.util.Arrays;

public class City {
    public String city;

    @Override
    public String toString() {
        return "" +
                "City: " + city + '\'';
    }

    public String district;

    public String[] streets;

    public String getCity() {
        return city;
    }
    public String getDistrict() {
        return district;
    }


    public String toStringStreets() {
        return "Streets of:"+getCity() + Arrays.toString(streets) +
                '}';
    }

    public String[] getStreets() {
        return streets;
    }


    public City(String city, String district, String[] streets) {
        this.city = city;
        this.district = district;
        this.streets = streets;
    }

}


