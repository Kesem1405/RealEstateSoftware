import java.util.Scanner;

public class Main {
    public static final int REGISTER = 1;
    public static final int LOGIN = 2;
    public static final int EXIT = 3;

    public static void main(String[] args) {
        realEstateAction();
    }
    public static void realEstateAction() {
        RealEstate realEstate = new RealEstate();
        Scanner scanner = new Scanner(System.in);
        int userSelection;
        User user = null;
        do {
            System.out.println("Welcome to my property app, What you want to do?");
            System.out.println("[1] - Create account");
            System.out.println("[2] - Login to account");
            System.out.println("[3] - Exit");
            userSelection = scanner.nextInt();
            switch (userSelection) {
                case REGISTER:
                   realEstate.createUser();
                   if (user!=null) {
                       user = realEstate.userLogin();
                   }
                    break;
                case LOGIN:
                    user = realEstate.userLogin();
                    if (user == null) {
                        System.out.println("Incorrect username or password! Returning to the main menu.");
                    }
                    else{
                        realEstate.userMainMenu(user);
                    }
                        break;
                case EXIT:
                    return;
                default:
                    System.out.println("Invalid selection, try again.");
                    break;
            }
        }    while(user == null);
    }
}