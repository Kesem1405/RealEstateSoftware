
public class Property {

    private User user;
    private City city;
    private String address;
    private int propertyType;
    private int propertyFloor;
    private int propertyNumber;
    private int propertyRooms;
    private final String dollar = "$";

    public int getPropertyRooms() {
        return propertyRooms;
    }

    public void setPropertyRooms(int propertyRooms) {
        this.propertyRooms = propertyRooms;
    }

    private String propertyCategory;

    public void setUser(User user) {
        this.user = user;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPropertyType(int propertyType) {
        this.propertyType = propertyType;
    }

    public void setPropertyFloor(int propertyFloor) {
        this.propertyFloor = propertyFloor;
    }

    public void setPropertyNumber(int propertyNumber) {
        this.propertyNumber = propertyNumber;
    }

    public void setPropertyCategory(String propertyCategory) {
        this.propertyCategory = propertyCategory;
    }

    public void setPropertyPrice(int propertyPrice) {
        this.propertyPrice = propertyPrice;
    }

    private int propertyPrice;

    public User getUser() {
        return user;
    }

    public City getCity() {
        return city;
    }

    public String getAddress() {
        return address;
    }

    public int getPropertyType() {
        return propertyType;
    }

    public int getPropertyFloor() {
        return propertyFloor;
    }

    public int getPropertyNumber() {
        return propertyNumber;
    }

    public String getPropertyCategory() {
        return propertyCategory;
    }

    public int getPropertyPrice() {
        return propertyPrice;
    }

    public Property() {

    }

    public String toString() {
        String output = this.city + ", " + getAddress() + "St.  " + this.propertyNumber + ". \n";
        switch (this.propertyType) {
            case Def.APARTMENT:
                output += "Regular apartment ";
                break;
            case Def.PENTHOUSE:
                output += "Penthouse apartment ";
                break;
            case Def.PRIVATE_HOUSE:
                output += "Private house ";
                break;
        }
        if (propertyCategory.equals("For rent")) {
            output += "For rent" + "\n";
        } else {
            output += "For sale" + "\n";
        }
        output += this.propertyRooms + " Rooms , floor: " + this.propertyFloor + ". \n";
        output += "Price: " + this.propertyPrice + Def.DOLLAR_SIGN+".\n";
        if (user != null) {
            output += "Contact: " + this.user.getUserName() + " " + this.user.getUserPhoneNumber() + ". \n";
            if (user.isBroker) {
                output += "[ Real estate broker ]";
            } else {
                output += "[ Private seller ]";
            }
        }
        return output;
    }
}
