import java.util.Arrays;
import java.util.Objects;
import java.util.Scanner;

public class User {

    public String userName;
    public String userPassword;

    public String userPhoneNumber;

    public boolean isBroker;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPhoneNumber() {
        return this.userPhoneNumber;
    }

    public void setUserPhoneNumber(String userPhoneNumber) {
        this.userPhoneNumber = userPhoneNumber;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public boolean isBroker() {
        return this.isBroker;
    }

    public void setBroker(boolean broker) {
        isBroker = broker;
    }

    public boolean isValidUserName(String userNameToAdd) {
        boolean valid = true;
        if (RealEstate.usersList.length > 0) {
            for (int i = 0; i < RealEstate.usersList.length; i++) {
                if (userNameToAdd.equals(RealEstate.usersList[i].getUserName())) {
                    valid = false;
                    break;
                }
            }
        }
        return valid;
    }

    public User(String userName, String userPassword, String userPhoneNumber, boolean isBroker) {
        this.userName = userName;
        this.userPhoneNumber = userPhoneNumber;
        this.userPassword = userPassword;
        this.isBroker = isBroker;
    }

    public User(){

    }

    public boolean equals(String userName, String userPassword){
        boolean isEquals = false;
        for(int i=0; i< RealEstate.usersList.length;i++){
            if (RealEstate.usersList[i].getUserName().equals(userName)) {
                if(RealEstate.usersList[i].getUserPassword().equals(userPassword)) {
                    isEquals = true;
                    break;
                }
            }
            else{
                break;
            }
        }
        return isEquals;
    }

    public boolean isPasswordValid(String userPassword) {
        boolean isPasswordValid = false;
        for (int i = 0; i < userPassword.length(); i++) {
            if (userPassword.charAt(i) == '%' || userPassword.charAt(i) == '$' || userPassword.charAt(i) == '_') {
                if (userPassword.length() >= 5) {
                    isPasswordValid = true;
                    break;
                }
            }
        }
        return isPasswordValid;
    }

    public boolean isPhoneNumberValid(String userPhoneNumber) {
        boolean isPhoneNumberValidCheck = false;
        if (userPhoneNumber.charAt(0) == '0' && userPhoneNumber.charAt(1) == '5') {
            if (userPhoneNumber.length() == 10) {
                if (userPhoneNumber.matches("[0-9]+")) {
                    isPhoneNumberValidCheck = true;
                }
            }
        }
        return isPhoneNumberValidCheck;
    }


    public String toString() {
        return "" +
                "User name =" + userName + '\n' +
                ", userPhoneNumber='" + userPhoneNumber + '\n' +
                ", userPassword='" + userPassword + '\n' +
                ", isBroker=" + isBroker +
                '}';
    }
}