public class Def {
    public static final int POST_PROPERTY = 1;
    public static final int FOR_SALE = 1;
    public static final int FOR_RENT = 2;
    public static final int APARTMENT = 1;
    public static final int PENTHOUSE = 2;
    public static final int REMOVE_PROPERTY = 2;
    public static final int PRIVATE_HOUSE = 3;
    public static final int ONE = 1;
    public static final char DOLLAR_SIGN = '$';
    public static final int NULL = 0;
    public static final int YES = 1;
    public static final int NO = 2;

    public static final int BROKER_PROPERTY_LIMIT = 5;
    public static final int USER_PROPERTY_LIMIT = 2;
    
    public static final int PRINT_ALL_PROPERTYS = 3;

    public static final int PRINT_ALL_USER_PROPERTYS = 4;
    public static final int PROPERTY_SEARCH = 5;
    public static final int FILTERING_PARAMETER = -999;
    public static final int EXIT = 6;



}
